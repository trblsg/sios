# P12.7.5.4.3 — one paired thermal build (revision 4)

Use kernel branch `s9/p12-4-guarded-thermal` and installer branch `fix/s9-p124-thermal-installer`. Use the kernel commit recorded in the host ZIP SHA256SUMS.json and the installer build's actual source manifest; do not mix BOOT/SYSTEM or host versions. Source and mock checks are not a native build or device qualification.

## Build once

Workflow s9-installer; kernel_ref=s9/p12-4-guarded-thermal; packaging_ref=main; partition=SYSTEM; metal=true; fps=true; time_limit=0; tweaks=true; userdata_blocks=starlte=13917184.

```text
hi=2 panel=1 p122=1 p12_gpu_boot_auto=1 mali_gov=1 mali_gov_frame=450 mali_probe=1 p3power=1 max77705_fg_s=10 p1273=1 p1274=1 p1275=1 p12751=1 p12752=1 p12753=1 p12754=1
```

Require P12754 paired source and staged XNU header preflight, then successful native build. Keep optimized PanVK and userdata. No boot-time floor/profile override, bus SET, direct rail writes, DCS/PSR boot experiments, physical CPU_OFF/CPU_SUSPEND or deep idle. Do not repeat old step 8; the previous reboot invalidated all same-boot qualifications. Historic 2.201 W is reference only, not a matched A0.

## 1. Fresh guard and connected read-only observation

Close PuTTY, substitute actual COM port. Start from cool boot, verify normal foreground, storage, wake, audio and Wi-Fi. Stop and cool on unexpected heat or abnormal behavior.

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario Guard53 -Port COM125 -Execute
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario Hardware54 -Port COM125 -Execute
```

P127543 uses the same p12754=1 boot flag but requires p12754_revision=4 (installer preflight). Hardware54 retains the revision 2 recorder. Hardware54 stays connected, screen OFF, GPU OFF, no interaction. Its bounded measurement is 60s after 1s quiet, with a maximum 90s WAIT. Only short CPU/UFS busy samples are skipped; continuous busy for 5s aborts, as do thermal/link/display/GPU/ownership changes. Offline quiet remains 20s. Require all 23 attempted hardware indices, valid paired thermal samples and no drops; unavailable GET/driver cache remains unavailable. Partial results do not require reflash or automatic retry. It does not arm a policy or claim battery watts. Export hardware54.csv, wait54.txt, wait541.txt (blocker rising-edge counts nBIT, duration ticks tBIT; divide by status hz, skips are active checks), ufs541.json (host bracket, not exact power interval or originating writer), audit53-status.json and raw log. ACPM GET returning zero means unavailable; PLL rate is not DRAM effective rate; BUCK2/3/6 VSEL is configured voltage, not a voltmeter. MFC and ISPPRE are ownership/clock diagnostics, not permission to power off an unowned domain. Audio cache may be unavailable if the owner is not active. Unsupported clock paths remain unknown.

## 2A. Prefer headless audio functional test (no GUI, no Preferences)

First run Guard53 and verify revision 4; Hardware54 is optional if hardware evidence is already available, not a power measurement. On a cool device, display OFF and USB connected, run:

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario FunctionalGate -GateModule ABOX -AllowFunctionalGate -HeadlessAudio -Port COM125 -Execute
```

Keep the display OFF throughout. The revision 4 headless gate uses 25 s idle before restore; all existing evidence remains mandatory. Once the headless review is requested, listen for the 2 s tone; speak continuously for several seconds afterwards; listen to the replay. Press Y on the PC only after hearing both tone and recorded speech. N rejects. Do not open apps or turn on the display. The existing root cputop sampler (5 s, infinite) claims exactly one request; it spawns only fixed tools, supervises them at 1 s while active, and otherwise adds no periodic idle timer. The worker requires actual AudioQueue, AVAudioRecorder nonempty PCM (>=90% of expected samples and nontrivial amplitude), AVAudioPlayer playback, existing kernel DMA/feed/capture/no-fault evidence, and operator confirmation. Each child is bounded to 12 s; host review to 55 s. No ACK on missing worker, silent/invalid capture, playback failure, timeout, changed screen, or thermal stop. Recording is local to /tmp/p127542-record.wav with restrictive creation mask and normal cleanup; an abrupt process crash can leave that temporary file until the next request. No audio file is exported. If the worker or microphone entitlement is unavailable, preserve the logs; do not fake a PASS. Native userland build and actual route/session behavior must be qualified.

After valid ABOX gate, use qualified connected assist if thermal headroom is limited. Do not require an offline energy PASS before subsequent connected floor qualification. When safe, obtain same-boot STOCK60 / BASE15 / STOCK60 then BASE15 / ABOX / BASE15 (individual matched comparisons). No prequalified combination based on earlier boots.

## 2A.1 Early idle assistance (not a battery measurement)

No mandatory 420/600s waiting period. From a cool boot and screen OFF, USB connected:

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario IdleAssist543 -GateModule BASE15 -AllowIdleAssist -AssistSeconds 60 -Port COM125 -Execute
# After ABOX HeadlessAudio gate passes in this boot:
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario IdleAssist543 -GateModule ABOX -AllowIdleAssist -AssistSeconds 60 -Port COM125 -Execute
```

BASE15 is the existing P126 baseline (not a new physical gate); every other assist requires its live same-boot kernel qualification including floor prerequisites. One module only. 15–90s host observation, kernel lease <=120s, no renewal. Screen/touch/thermal/link/qualification/ownership changes revoke. No USB disconnect during assist. Capture guard and rate rows, UFS error deltas and restoration. A falling temperature is not a matched energy result. Assist is stopped before any other test; do not claim it is an always-on boot optimization.

## 2A.2 Headless network checks

Prepare an actual peer capable of bidirectional traffic over the radio in question. Example Wi-Fi:

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario FunctionalGate -GateModule WIFI -AllowFunctionalGate -HeadlessNetwork -Port COM125 -Execute
```

BT and TICKER use the same command with GateModule changed. During the 45s active period and the 35s restored review, verify genuine traffic/reconnect from the peer (ticker: timing/cancel). Screen stays OFF. Y only after real function; N rejects. Kernel still requires attach/detach, IRQ/handled and RX/TX before and after restore or ticker wait/due/wake/cancel evidence. No peer or no observable traffic means no qualification. This is not automatic network provisioning. WFI >3.5ms is a histogram observation, not proof of safe CPU_SUSPEND.

## 2B. Short foreground GPU trials (optional, separate from battery measurements)

Do not add mali_irq=1 or g2_bind=1 to the baseline boot args. Only when cool and after the audio/idle work, run one test at a time, with identical Home/lock interaction, matched starting temperatures and cooldown between tests:

```powershell
.\s9-p125-timer-serial.ps1 -P12754 -Scenario Foreground542 -AllowGpu542 -Gpu542Mode Baseline -Port COM125 -Execute
.\s9-p125-timer-serial.ps1 -P12754 -Scenario Foreground542 -AllowGpu542 -Gpu542Mode IRQ -Port COM125 -Execute
.\s9-p125-timer-serial.ps1 -P12754 -Scenario Foreground542 -AllowGpu542 -Gpu542Mode Baseline -Port COM125 -Execute
# Only after IRQ comparison, repeat Baseline / G2 / Baseline in separate runs.
.\s9-p125-timer-serial.ps1 -P12754 -Scenario Foreground542 -AllowGpu542 -Gpu542Mode G2 -Port COM125 -Execute
```

Eight-second connected foreground windows; no app launch. Keep early thermal stops unchanged. IRQ uses existing native IRQ attach/poll fallback and host finally restores zero; if serial disappears, restoration must be verified before another test (or reboot). G2 is a 15 s foreground-only kernel lease, revoked by thermal/display and sampled at the existing userland render-frame poll; diagnostic baseline and boot-time G2 prohibition remain intact. Verify first skip and every 128th candidate against native binding, disable that context on mismatch, retain all IOSurface checks. Compare actual log waits/fallbacks, skip/mismatch, frame/UI and CPU data, not readback alone. No combined GPU optimization or power claim yet.

## 2. Offline energy contrast

Use the same boot and equal 60s windows, with cool matched starting conditions. The new offline arm and WAIT headroom require BIG <=60C, LITTLE <=59C, GPU <=60C, battery below 45C and fresh samples. Existing hard cutoffs remain unchanged. Read wait54.txt after a refusal or cutoff. Do not warm the device to qualify it.

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario Audit53 -Audit53Module STOCK60 -AllowOfflineTrial -WaitCoolSeconds 120 -Port COM125 -Execute
```

At OFFLINE ARMED unplug USB. If it wakes the screen, turn it OFF once and leave the device alone on a nonflammable surface. Kernel requires link down, fresh discharging FG, OFF/GPU OFF, quiet input/UFS/load continuously for 20s. Revision 4 retains 90s WAIT, shifted once to physical disconnect if it occurs within 15s of arm (absolute maximum 105s from arm); it never renews. A thermal-only plateau with no >=0.5C progress for 30s stops the kernel WAIT; wait543.json records plateau and deadline. Host cannot see the frozen state while unplugged; it conservatively waits 170s after handle loss for 60s trials or 230s for STOCK120. Press N on PC to request early reconnect if heat or abnormal behavior requires stopping; no valid power claim on an interrupted measurement. Connected WaitCoolSeconds also exits on a thermal plateau. Boot uptime is recorded and warns before 420s; not an admission gate. No automatic rearm. Do not reboot before readback recovery.

For BASE15: STOCK60 / BASE15 / STOCK60. For an individual intervention: BASE15 / B / BASE15. Each command replaces Audit53Module with that phase. For ABOX/BT/WIFI/TICKER/LITTLE949, first prove the connected functional gate on the same boot:

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario FunctionalGate -GateModule LITTLE949 -AllowFunctionalGate -Port COM125 -Execute
```

Follow the physical prompts; LITTLE uses an 18s active window, two bounded BUCK3 VSEL reads with fresh measured floor, and a 12s UI review. Wake reason4 or reason7 is accepted by the kernel only for the exact stopped lease and actual display wake within 2s of stop, after arm. Press Y after normal touch/UI; host waits for measured stock evidence as well, then checks unchanged UFS errors before ACK. Report floor543-qualified.json contains same-boot generation, two configured VSEL readings, UFS bracket and measured stock; it is not power evidence. Use the headless ABOX command above; other module checks remain unchanged. Prioritize ABOX and LITTLE949, not a repeated Hardware54 PASS. Revision 2 ABOX resume requires observed in-ring DMA movement, not just ENABLE. Verify playback, microphone and routing; no ACK if any fail. ACK only after actual successful testing. For PSR use the existing connected EnergyTrials -P12752Idle -EnergyModules PSR -EnergySeconds 30 and pass the reviewed same-boot report via -Audit53PriorReport. Do not combine interventions. Use Hardware54 instead of BUS offline.

Compare in a PowerShell session:
```powershell
.\s9-p125-timer-serial.ps1 -P12754 -Scenario Audit53Compare -Audit53Reports @('A0.audit53-power.json','B.audit53-power.json','A1.audit53-power.json')
```

Require verified power, application, restore, same boot, chronology, matched temperatures and voltage, and acceptable baseline drift. Marginal mW values are not additive or rail-specific. Revision 2 includes both BUCK3 configured uV samples per phase and A/B/A rail comparison; all_B_below_baseline is true only if both B readings are below all A readings. This is not rail power. ABOX report includes stop/resume/idle_wait/fault deltas. Missing/false power_verified is not a power result; applied=false does not support a causal comparison.

## 3. Graduated LITTLE floor

Only advance 949 -> 832 -> 715 -> 598 MHz after the previous floor has completed same-boot functional qualification and BUCK3/UFS evidence. Revision 4 allows the actual preceding floor543-qualified.json instead of a completed battery comparison. This separates functional/rail safety from energy qualification, not a bypass of kernel gate or UFS. No 455 MHz in P12754. Use the preceding floor's actual report for both gate and offline arm, or retain the older reviewed A/B/A path. Example:

```powershell
$prior='actual-LITTLE949.floor543-qualified.json'
.\s9-p125-timer-serial.ps1 -P12754 -Scenario FunctionalGate -GateModule LITTLE832 -AllowFunctionalGate -AllowLowerFloor -ConnectedFloorReport $prior -Port COM125 -Execute
# If cool enough, run a new BASE15 A0 before B, then:
.\s9-p125-timer-serial.ps1 -P12754 -Scenario Audit53 -Audit53Module LITTLE832 -AllowOfflineTrial -AllowLowerFloor -ConnectedFloorReport $prior -Port COM125 -Execute
# Run BASE15 A1 and compare. For 715 use the successful 832 connected report; for 598 use 715.
```

Do not advance after a failed gate, UFS error/restore problem, missing rail evidence, thermal cutoff or wake interruption. A missing battery window alone is not a failed connected qualification. Require sampled measured MHz, actual applied floor, BUCK3 configured VSEL evidence, restore to normal stock floor, and stable functional behavior.

## 4. Background owner and UFS analysis (separate from power phases)

Use the existing ThermalTrace and ThermalTraceDump on a separate bounded stock observation, only with sufficient thermal headroom. Preserve any frozen trace; no overwrite or reboot solely for this test.

```powershell
.\s9-p125-timer-serial.ps1 -Scenario ThermalTrace -Port COM125 -Execute
.\s9-p125-timer-serial.ps1 -Scenario ThermalTraceDump -Port COM125 -Execute
.\s9-p127541-background.ps1 -SamplesCsv .\run.samples.csv -RawLog .\run.log -ThermalPages .\dump.thermal-pages.txt -ThermalStatus .\dump.thermal-status.clixml
```

Use actual filenames. Omit both thermal arguments for existing logs without a frozen dump. Output is JSON on stdout, no serial I/O. PID/task/TID ranking is limited to observed frozen pages; UFS summaries and CPU activity do not identify the originating writer. AUD selected-source clock now uses the owner's fractional decoder. MIF effective-rate lowering, MFC/ISPPRE power-off/restore remain unimplemented pending verified driver ownership, clocks and save/restore. No direct PMU/SMC writes. No default recommended-core restriction or hard PosterBoard/GPU job block; these would confound floor tests. Existing ABOX 100ms missed-event watchdog remains (headphone route timeout requires margin), and USB link changes now signal the audio event as well.

## 5. Frozen recovery

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario Audit53Recover -Audit53Checkpoint .\original.audit53-checkpoint.clixml -Port COM125 -Execute
```

Recover only the matching boot/arm/frozen phase. Never replay an arm or policy write on a missing echo. If measurement never started, status/WAIT blockers are the evidence; no samples exist to recover. Send all files with the run stem, including audit53-power.json, audit53-status.json, audit53-rows.csv, hardware54.csv, wait54.txt, audit53-counters.csv, FG/WFI CSVs, checkpoint and raw log.
