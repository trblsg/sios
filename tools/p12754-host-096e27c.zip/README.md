# P12.7.5.4 — one paired thermal build

Use kernel branch `s9/p12-4-guarded-thermal` and installer branch `fix/s9-p124-thermal-installer`. Use the kernel commit recorded in the host ZIP SHA256SUMS.json and the installer build's actual source manifest; do not mix BOOT/SYSTEM or host versions. Source and mock checks are not a native build or device qualification.

## Build once

Workflow s9-installer; kernel_ref=s9/p12-4-guarded-thermal; packaging_ref=main; partition=SYSTEM; metal=true; fps=true; time_limit=0; tweaks=true; userdata_blocks=starlte=13917184.

```text
hi=2 panel=1 p122=1 p12_gpu_boot_auto=1 mali_gov=1 mali_gov_frame=450 mali_probe=1 p3power=1 max77705_fg_s=10 p1273=1 p1274=1 p1275=1 p12751=1 p12752=1 p12753=1 p12754=1
```

Require P12754 paired source and staged XNU header preflight, then successful native build. Keep optimized PanVK and userdata. No boot-time floor/profile override, bus SET, direct rail writes, DCS/PSR boot experiments, physical CPU_OFF/CPU_SUSPEND or deep idle. Do not repeat old step 8; the previous reboot invalidated all same-boot qualifications. Historic 2.201 W is reference only, not a matched A0.

## 1. Fresh guard and connected read-only observation

Close PuTTY, substitute actual COM port. Start from cool boot, verify normal foreground, storage, wake, audio and Wi-Fi. Stop and cool on unexpected heat or abnormal behavior.

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario Guard53 -Port COM125 -Execute
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario Hardware54 -Port COM125 -Execute
```

Hardware54 stays connected, screen OFF, GPU OFF, no interaction. Its bounded measurement is 60s after 20s quiet, with a maximum 90s WAIT. It does not arm a policy or claim battery watts. Export hardware54.csv, wait54.txt, audit53-status.json and raw log. ACPM GET returning zero means unavailable; PLL rate is not DRAM effective rate; BUCK2/3/6 VSEL is configured voltage, not a voltmeter. MFC and ISPPRE are ownership/clock diagnostics, not permission to power off an unowned domain. Audio cache may be unavailable if the owner is not active. Unsupported clock paths remain unknown.

## 2. Offline energy contrast

Use the same boot and equal 60s windows, with cool matched starting conditions. The new offline arm and WAIT headroom require BIG <=60C, LITTLE <=59C, GPU <=60C, battery below 45C and fresh samples. Existing hard cutoffs remain unchanged. Read wait54.txt after a refusal or cutoff. Do not warm the device to qualify it.

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario Audit53 -Audit53Module STOCK60 -AllowOfflineTrial -Port COM125 -Execute
```

At OFFLINE ARMED unplug USB. If it wakes the screen, turn it OFF once and leave the device alone on a nonflammable surface. Kernel requires link down, fresh discharging FG, OFF/GPU OFF, quiet input/UFS/load continuously for 20s. Host conservatively waits 155s after handle loss for 60s trials; reconnect only on prompt unless heat/abnormal behavior requires stopping. For STOCK120 the host waits 215s. No automatic rearm. Do not reboot before readback recovery.

For BASE15: STOCK60 / BASE15 / STOCK60. For an individual intervention: BASE15 / B / BASE15. Each command replaces Audit53Module with that phase. For ABOX/BT/WIFI/TICKER/LITTLE949, first prove the connected functional gate on the same boot:

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario FunctionalGate -GateModule LITTLE949 -AllowFunctionalGate -Port COM125 -Execute
```

Follow the physical prompts; wake and verify UI and normal storage, or the corresponding audio/BT/Wi-Fi/ticker function. ACK only after actual successful testing. For PSR use the existing connected EnergyTrials -P12752Idle -EnergyModules PSR -EnergySeconds 30 and pass the reviewed same-boot report via -Audit53PriorReport. Do not combine interventions. Use Hardware54 instead of BUS offline.

Compare in a PowerShell session:
```powershell
.\s9-p125-timer-serial.ps1 -P12754 -Scenario Audit53Compare -Audit53Reports @('A0.audit53-power.json','B.audit53-power.json','A1.audit53-power.json')
```

Require verified power, application, restore, same boot, chronology, matched temperatures and voltage, and acceptable baseline drift. Marginal mW values are not additive or rail-specific. Missing/false power_verified is not a power result; applied=false does not support a causal comparison.

## 3. Graduated LITTLE floor

Only advance 949 -> 832 -> 715 -> 598 MHz after the previous floor has completed same-boot functional qualification and reviewed verified A/B/A with BUCK3 evidence. No 455 MHz in P12754. For each new level, pass the immediately preceding floor's actual A0/B/A1 power JSON to BOTH gate and offline arm. Example:

```powershell
$prior=@('previous-A0.audit53-power.json','previous-B.audit53-power.json','previous-A1.audit53-power.json')
.\s9-p125-timer-serial.ps1 -P12754 -Scenario FunctionalGate -GateModule LITTLE832 -AllowFunctionalGate -AllowLowerFloor -Audit53Reports $prior -Port COM125 -Execute
# Run a new BASE15 A0 before B, then:
.\s9-p125-timer-serial.ps1 -P12754 -Scenario Audit53 -Audit53Module LITTLE832 -AllowOfflineTrial -AllowLowerFloor -Audit53Reports $prior -Port COM125 -Execute
# Run BASE15 A1 and compare before any further step.
```

Do not advance after a failed gate, UFS activity/restore problem, invalid measurement, thermal cutoff or wake interruption. Require sampled measured MHz, actual applied floor, BUCK3 configured VSEL evidence, restore to normal stock floor, and stable functional behavior.

## 4. Frozen recovery

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -P12754 -Scenario Audit53Recover -Audit53Checkpoint .\original.audit53-checkpoint.clixml -Port COM125 -Execute
```

Recover only the matching boot/arm/frozen phase. Never replay an arm or policy write on a missing echo. If measurement never started, status/WAIT blockers are the evidence; no samples exist to recover. Send all files with the run stem, including audit53-power.json, audit53-status.json, audit53-rows.csv, hardware54.csv, wait54.txt, audit53-counters.csv, FG/WFI CSVs, checkpoint and raw log.
