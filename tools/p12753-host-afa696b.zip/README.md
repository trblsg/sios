# P12.7.5.3 — one build, independent boot guard and battery audit

Kernel afa696bb81a9b444f4944530d2b1541261910a99, branch s9/p12-4-guarded-thermal.
Use p12753-host-afa696b.zip (all four matching scripts, not the P12752 host-only hotfix).
Source/host checks are not native XNU build, device or thermal/power qualification.

## Build once

Workflow s9-installer, branch fix/s9-p124-thermal-installer.
kernel_ref=s9/p12-4-guarded-thermal; packaging_ref=main; partition=SYSTEM.
metal=true, fps=true, time_limit=0, tweaks=true, userdata_blocks=starlte=13917184.

```text
hi=2 panel=1 p122=1 p12_gpu_boot_auto=1 mali_gov=1 mali_gov_frame=450 mali_probe=1 p3power=1 max77705_fg_s=10 p1273=1 p1274=1 p1275=1 p12751=1 p12752=1 p12753=1
```

Use paired BOOT/SYSTEM from same run; keep OptEarly/optimized PanVK, retain userdata.
Do not add p1272_probe, fb_psr, bus_max, bus_mask, gov_policy or OPP/voltage overrides, CPU_OFF/CPU_SUSPEND, syssleep, panel_sleep or DCS experiments.
Confirm P12753 source preflight and staged header verification. Native compilation is required in installer.

## First: prove normal-boot thermal guard

Fresh cool boot, no other policy/profile arm. Close PuTTY when using host script.
Observe natural boot and poster workload, including 290–390s; don't induce overheating.
Read-only:
```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -Scenario Guard53 -Port COM125 -Execute
```
Save raw log and .guard53.txt; peak BIG/LITTLE, cap transitions, direct TMU age and actual measured CPU rates. Aim for peak <=74C, not a promised outcome. Check wake, display, audio, Wi-Fi and storage. If unstable or hot, stop and cool; do not proceed to battery trials.

## Stock battery baseline, after guard review

Same boot (no active leases); cool device, screen OFF, connected USB and valid fuel gauge. Replace COM125 with actual port.
```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -Scenario Audit53 -Audit53Module STOCK120 -AllowOfflineTrial -Port COM125 -Execute
```
At OFFLINE ARMED unplug USB. If screen wakes, press POWER once to turn it OFF, or allow it to turn OFF itself. Leave device alone on a nonflammable surface. The kernel waits for real USB down, fresh external=0 FG, OFF/GPU OFF and quiet conditions continuously sampled for 20s; the wait is bounded by 90s from arm. Thereafter a 120s window or early cutoff freezes in RAM. Host cannot see device while disconnected; it waits the conservative 215s after handle loss, then prompts RECONNECT USB NOW. Only reconnect on prompt unless heat or abnormal behavior requires stopping; do not wait through overheating. Screen wake during reconnect is allowed. Never wake again during active measurement. No automatic rearm.

Send raw log, audit53-status.json, audit53-rows.csv, audit53-power.json, audit53-counters.csv, AUDIT53.wfi.csv, AUDIT53.fg.csv, audit53-checkpoint.clixml and other files with same stem. Missing/false power_verified is not a power result.

If transport/readback fails, keep same boot and let the original audit freeze; when cool reconnect and recover using exact checkpoint path:
```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -Scenario Audit53Recover -Audit53Checkpoint .\<original>.audit53-checkpoint.clixml -Port COM125 -Execute
```
Recovery only reads frozen audit, except bounded cursor selection. No reboot before recovery.

## Bus diagnostic and individual power trials, after baseline review

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -Scenario Audit53 -Audit53Module BUS -AllowOfflineTrial -Port COM125 -Execute
```
BUS is separate diagnostic window (120s); 13 GET attempts and PMU samples, not an ABA baseline. Export audit53-bus.csv. Raw PMU lower bits represent status, UINT32_MAX unknown. GET errno/raw/valid and OPP table voltage do not prove rail voltage. No bus SET.

For BASE15 contrast use STOCK60, BASE15, STOCK60 in that order, same boot, cool matched conditions; run the same Audit53 command with each module. For another module use BASE15, B, BASE15. All 60s phases, host 155s conservative wait. No automatic progression. A0 and A1 must match temperatures and FG voltage; failed/partial/thermal/wake phases rejected. Check restored mode=0 and actual functionality before moving on.

PSR: run connected EnergyTrials -P12752Idle -EnergyModules PSR -EnergySeconds 30 -Port COM125 -Execute first; verify successful wake/no tearing and completed applied A/B/A report; same boot mask/unmask evidence required. Pass -Audit53PriorReport <reviewed-report.txt> to Audit53 PSR. No boot fb_psr or DCS.

ABOX, BT, WIFI, TICKER, LITTLE949 require existing same-boot FunctionalGate qualification: -Scenario FunctionalGate -GateModule <module> -AllowFunctionalGate -Port COM125 -Execute. Follow host prompts and physically verify the specific function; no synthetic approval. Then Audit53 -Audit53Module <module> -AllowOfflineTrial. Use exact one module, no combined or lower floor offline in this new audit. Older EnergyTrials qualified LITTLE832/715/598/455 and s9-p1274-serial.ps1 REC2/1/0 remain available separately; not new battery-energy qualifications. USB connected polling isolated using existing USB EnergyTrials. Bus SET and physical CPU idle states are deliberately not implemented.

Compare actual A0/B/A1 power JSON in the same PowerShell session:
```powershell
.\s9-p125-timer-serial.ps1 -Scenario Audit53Compare -Audit53Reports @('A0.audit53-power.json','B.audit53-power.json','A1.audit53-power.json')
```
The local comparison requires power_verified/applied/restored, same boot, chronological same-duration phases, starting BIG/LITTLE within 2C, mean voltage within 150mV, baseline drift <=10%. Reports marginal mW only, not additive or rail-specific watts. STOCK still includes independent boot guard; old 2.183W is a historical approximate observation, not matched A0.

See kernel docs/s9-p12753-implementation-status.md for full ABI, masks, limits and deferred work.
