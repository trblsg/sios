# P12.7.5.1 — PanVK dual variant / protected boot and ICD evidence

Kernel commit `403f7600aac682c89e4653d244655984b2f744b4`.
Host kit `tools/p12751-host-403f760.zip`. Use the new kit, not P1275.

## Build once
Workflow s9-installer; branch fix/s9-p124-thermal-installer.
kernel_ref=s9/p12-4-guarded-thermal; packaging_ref=main; partition=SYSTEM.
metal=true, fps=true, time_limit=0, tweaks=true, userdata_blocks=starlte=13917184.

```text
hi=2 panel=1 p122=1 p12_gpu_boot_auto=1 mali_gov=1 mali_gov_frame=450 mali_probe=1 p3power=1 max77705_fg_s=10 p1273=1 p1274=1 p1275=1 p12751=1
```

Do not enable p1272_probe=1, metal_layout=1, p_layout_probe=1, sleep_cores,
syssleep, panel_sleep, mali_dvs, p9_panel_mode, gov_policy=3, fb_psr,
or frequency/voltage overrides. Use matching BOOT/SYSTEM and retain
userdata on subsequent reboots. Native build must succeed before flash.
Download **p12751-panvk-macho** after build: both actual input dylibs,
audits, decoded bindings, plan and verification report. Verify optimized
driver has zero flat/dynamic bindings, preserved 137 exports for the
reference ABI, and unchanged legitimate libSystem pthread weak imports.
Strict-link/provenance checks are build gates, not runtime performance
proof. Send artifact with logs.

## First trial — OptEarly + EarlyLoad
Default new boot preference is OptEarly (optimized driver plus early
layout nil). Expect latch=3 or 7; bit 2 means retained data. Host checks
variant before arming. Actual opener path should name
/redwood/lib/libvulkan_panfrost_opt.dylib;
check ABI reason and early_nil/use counters rather than assume success.
Fresh cooled boot, screen OFF, USB connected, close PuTTY. Arm before
uptime 225s. No touch/swipe during the measurement. Existing hard stops
BIG76/LITTLE70/GPU72 and absolute deadline 720s unchanged. EarlyLoad
uses NOW with no coordination; preemptive load envelope begins after arm.

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Profile LOG2 -Experiment EarlyLoad -BootVariant OptEarly -AllowIntervention -Port COM125 -RunDir .\logs\P12751-OptEarly-A0 -Execute
```

COM125 is an example; substitute the actual port. If latch or actual
driver is wrong, stop and report rather than relabel the trial. If
thermal stop occurs, cool first. Do not force repeated hot captures.

## Dump and analyze
Same boot only; do not reboot before retrieving evidence. Dump once cool;
the stage recorder allows only already-started completions up to 10s
after freeze. No new workload is started to complete evidence.

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Action Dump -Port COM125 -RunDir .\logs\P12751-OptEarly-A0 -MaxPages 192 -Execute
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Action Analyze -RunDir .\logs\P12751-OptEarly-A0 -Execute
```

Send whole directory even if dump_complete=false. Key additional outputs:
metal-stages-p12751.csv (boot/active/tail stage measurements and image
counts, censored rows explicit), trace-coverage.csv (owner losses),
thread-placement, raw alignment/cputop/media observations and ABI logs.
Partial evidence is not hardware qualification. Continue bounded Dump
only if safe and on same boot.

## Subsequent comparison — after review, no new flash
The root-owned preference is applied by PID 1 before launchd.
Variants: Stock=0, Opt=1, StockEarly=2, OptEarly=3. It is not possible
to change loaded driver handles live. To compare weak-binding change
alone, match early mode and runtime experiment across cold boots.

Example: after OptEarly capture and review, cooled same boot screen OFF:

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Action NextBoot -BootVariant StockEarly -AllowIntervention -Port COM125 -RunDir .\logs\P12751-OptEarly-A0 -Execute
```

Only reboot manually after valid nextboot.json/ACK; verify latch on
the next run, and use a fresh directory. No persistence if retained
data is unavailable; do not assume mode switched without ACK/readback.
No automatic reboot or progression. Do not run Offline or R profiles
until separately reviewed. Native SDK/Mesa/kernel link and actual
device functionality not verified locally. Alignment return remains
unchanged; lower LITTLE floor, CPU parking, architecture pruning and
chained fixups deferred. See kernel docs/s9-p12751-implementation-status.md.
