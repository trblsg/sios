# P12.7.4.1 — Hướng dẫn kiểm thử bảo vệ nhiệt

Kernel commit `85d8ee69342e3f9a51f8fe8ca417c71441c54958`.
Host kit `tools/p12741-host-85d8ee6.zip`, ABI revision 2. Không dùng
ZIP P12.7.4 cũ; endpoint arm đã đổi thành p12741_profile. Một build/flash,
reboot giữa các profile; cùng BOOT/SYSTEM, không dùng mixed firmware.

## Build

- sios / s9-installer / fix/s9-p124-thermal-installer
- kernel_ref=s9/p12-4-guarded-thermal, packaging_ref=main, partition=SYSTEM
- metal=true, fps=true, time_limit=0, tweaks=true, userdata_blocks=starlte=13917184
- Boot args:

```text
hi=2 panel=1 p122=1 p12_gpu_boot_auto=1 mali_gov=1 mali_gov_frame=450 mali_probe=1 p3power=1 max77705_fg_s=10 p1273=1 p1274=1
```

Bỏ p1272_probe=1. Không thêm sleep_cores=1, syssleep=1, panel_sleep=1,
mali_dvs=1, p9_panel_mode=1, metal_layout=1, gov_policy=3, fb_psr=100,
tmu_poll=200, boot cap hoặc các mode/profile. Chỉ flash sau khi xác minh
build thành công và đúng kernel SHA. Native build chưa được xác minh
trong máy local; portable C tests được yêu cầu trong CI/preflight.

## Lượt đầu — LOG2 Connected (ưu tiên an toàn)

Vì A0 cũ chạm 88 C, dùng LOG2 trước, giữ protection chung của BASE/LOG2
và suppress hai nhóm log unsupported. Không cần tái tạo đỉnh 88 C.
Giải nén ZIP, mở PowerShell ở thư mục script, đóng PuTTY. COM125 chỉ là ví dụ.
Boot khi máy đã nguội. Màn hình OFF; nếu script yêu cầu thì nhấn POWER một lần.
Bắt đầu sớm, arm trước uptime 225s. Không vuốt/chạm trong lúc đo.

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Profile LOG2 -Port COM125 -RunDir .\logs\P12741-LOG2-A0 -Execute
```

Script verify ABI revision 2, chờ OFF 25s và GPU OFF. TFR mở 230s;
eligible 240s; deadline 720s hoặc dừng bảo vệ sớm. Guard chỉ bắt đầu sau
arm thành công; sau đó hoạt động đến reboot, kể cả mất USB/dừng recorder.
Không coi mục tiêu 200ms là bảo đảm nhiệt độ luôn dưới 76C.

Nếu máy nóng hoặc guard báo dừng, không cố tiếp tục đo; đưa về recovery
nếu cần để an toàn. Không reboot chỉ để Dump nếu máy đã nguội và vẫn
an toàn: dữ liệu frozen nằm trong RAM và mất sau reboot.

## Dump ưu tiên, Analyze ngay

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Action Dump -Port COM125 -RunDir .\logs\P12741-LOG2-A0 -MaxPages 128 -Execute
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Action Analyze -RunDir .\logs\P12741-LOG2-A0 -Execute
```

Gửi toàn bộ thư mục log ngay sau lượt đầu, không cần Dump hết hàng nghìn
trang để nhận đánh giá ban đầu. Nếu cùng boot còn nguội, chạy lại Dump
cùng thư mục (có thể hạ -MaxPages 32 hoặc 64). Checkpoint bỏ qua trang
đã lưu; chỉ tạo dump.complete khi đầy đủ. Không đổi boot hoặc sửa summary.
Mỗi batch có live thermal guard, không nới các ngưỡng. Raw lines trước
*.sync.json clock/nonce ACK có thể là backlog; không suy ra realtime từ
thời điểm host nhận. episode-info.txt có peak/index ngay cả khi partial.

Giữ *.log, *.journal.txt, *.sync.json, *.samples.csv, capture.json,
status.txt, episode-info.txt, trace-status.txt, pages.txt, trace-pages.txt,
trace-cpu*.txt, GPU files, restore.json, summary.json, CSV exports, wake.json
và dump.complete (nếu có). Peak trong frozen record khác peak guard kể
từ lúc arm; guard có thể ghi thêm nhiệt sau freeze.

## Sau khi review lượt đầu

Nếu LOG2 ổn định, cùng điều kiện nhiệt/pin/wallpaper, reboot cho BASE và
LOG2 đối chứng; BASE cũng được bảo vệ chủ động, không phải BASE cũ.
Mỗi profile dùng RunDir mới. Không so trực tiếp như A/B giữa ABI 1 và 2.
FAST/B1/B2/B3/R2/R1/R0 chỉ sau review; FAST/B/R yêu cầu -AllowIntervention,
một touch thật khi ON rồi POWER OFF, kernel input quiet/UFS gate.
B2/B3/R yêu cầu summary revision 2 qualified của pha trước theo thứ tự.
Không vô hiệu OCP/CPU_OFF/SUSPEND để đạt qualification.

Sau full Dump, bật màn hình, thử UI/touch, radio/audio khi nguội, rồi:
```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Action WakeCheck -Port COM125 -RunDir .\logs\P12741-LOG2-A0 -ConfirmForeground -Execute
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Action Analyze -RunDir .\logs\P12741-LOG2-A0 -Execute
```

Offline chỉ sau khi connected được review và đủ an toàn; -Power Offline
-AllowOffline, giữ cáp rút theo hướng dẫn đến sau 720s. Net pin Wh chỉ
đo hợp lệ cửa sổ 250–710s, USB/FG bracketing đầy đủ, không phải wall watts.
LOG2/FAST suppress hai log lặp đến reboot nhưng không ghi events sau
freeze. TFR chỉ có một owner PID/TID chi tiết cho major đầu tiên;
32 episode compact ghi nhiều burst (tối đa 40 mẫu đầu mỗi burst),
không thay cho nhiều owner trace. Chưa xác nhận hardware hiệu quả.
