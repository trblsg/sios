# P127545 / revision 6 — S9 starlte
Status: revision 6 native compile hotfix candidate (corrected the pilot cancellation flag name from the initial 75d4eab build). No boot-argument or ABI change. Do not flash until the integrated native installer Action passes and the exact kernel/installer commits match the release kit manifest. No power saving or device qualification is claimed by the source checks.

## Build once
Workflow s9-installer; kernel_ref=s9/p12-4-guarded-thermal (required branch input; exact commit additionally enforced by the published source lock); packaging_ref=main; partition=SYSTEM; metal=true; fps=true; tweaks=true; time_limit=0; userdata_blocks=starlte=13917184. Installer branch fix/s9-p124-thermal-installer. All three revision-6 opt-ins are required together.

Boot args (single line):
```text
hi=2 panel=1 p122=1 p12_gpu_boot_auto=1 mali_gov=1 mali_gov_frame=450 mali_probe=1 p3power=1 max77705_fg_s=10 p1273=1 p1274=1 p1275=1 p12751=1 p12752=1 p12753=1 p12754=1 p127545_qch=1 p127545_disp=1 p127545_ect=1
```

Keep stock mfc_irq=1. Do not add active INT, panel sleep or HCI injection boot controls. Verify source preflight, staged header checks, linked kernel and EFI markers, and successful installer artifact. Verify ZIP hash and SHA256SUMS.json before running. The published installer must include tools/p127545-kernel.sha with the exact kernel commit; the Action rejects drift even if kernel_ref names the right branch. SOURCE-MANIFEST.json inside the encrypted build must match the host kit's kernel_commit and installer_commit, with p12754_revision=6. The kit is published on a separate host branch so adding the ZIP cannot change the source commit. Local packer requires both exact committed SHAs:
```powershell
.\tools\package-p127545-host.ps1 -KernelCommit <40-hex> -InstallerCommit <40-hex>
```

## Same boot prerequisites
Extract kit, close all serial readers, use actual COM port. Keep device cool; touch once with screen on, then turn screen off. In PowerShell in the kit directory:
```powershell
$port='COM125' # replace with actual port
$s='.\s9-p125-timer-serial.ps1'
& $s -Port $port -P12754 -Scenario Guard53 -Execute
& $s -Port $port -P12754 -Scenario Hardware54 -Execute
& $s -Port $port -P12754 -Scenario FunctionalGate -GateModule LITTLE949 -AllowFunctionalGate -Execute
```

Follow each host prompt. Advance only on successful same-boot functional/rail/UFS proof. For each lower floor, use actual preceding floor543-qualified.json path (not floor543-rail.json):
```powershell
& $s -Port $port -P12754 -Scenario FunctionalGate -GateModule LITTLE832 -AllowFunctionalGate -AllowLowerFloor -ConnectedFloorReport 'ACTUAL-949.floor543-qualified.json' -Execute
& $s -Port $port -P12754 -Scenario FunctionalGate -GateModule LITTLE715 -AllowFunctionalGate -AllowLowerFloor -ConnectedFloorReport 'ACTUAL-832.floor543-qualified.json' -Execute
& $s -Port $port -P12754 -Scenario FunctionalGate -GateModule LITTLE598 -AllowFunctionalGate -AllowLowerFloor -ConnectedFloorReport 'ACTUAL-715.floor543-qualified.json' -Execute
& $s -Port $port -P12754 -Scenario FunctionalGate -GateModule ABOX -AllowFunctionalGate -HeadlessAudio -Execute
```

Replace the ACTUAL placeholders before running. Audio review requires actual tone and recorded playback. Y only if heard and correct; otherwise N. No Y for an unobserved result. A failed or missing prerequisite prohibits the dependent module. No repeat on a revoked lease or uncertain restore.

## First battery A/B/A
Each run starts USB connected, screen OFF. Warm precondition 15s; continuous quiet 20s; valid window 60s; extended WAIT up to 150s with LongWait545. At OFFLINE ARMED unplug promptly; if screen wakes turn it OFF once, leave alone, reconnect only at host prompt. Observe thermal and stop conditions. Keep the same profile for A0/B/A1. Do not rearm after failure.
```powershell
$a=@{Port=$port;P12754=$true;Scenario='Audit53';WarmAudit=$true;LongWait545=$true;AllowOfflineTrial=$true;WaitCoolSeconds=60;Execute=$true}
& $s @a -Audit53Module STOCK60
& $s @a -Audit53Module COMPOSITE69 -AllowComposite545
& $s @a -Audit53Module STOCK60
& $s -P12754 -Scenario Audit53Compare -Audit53Reports @('ACTUAL-A0.json','ACTUAL-B.json','ACTUAL-A1.json')
```

Use actual audit report paths printed by host. Composite69 requires BASE + ABOX + LITTLE598 and qualification mask 7202. Optional WIFI/BT/TICKER bits are not required. Compare only verified, restored, same-boot, ordered and matched windows. Do not add independent savings estimates.

## Isolated DISP
Connected pilot at screen OFF, then wake as prompted. Verify fresh scanout and visible operation; Y only if correct. Run 134 MHz pilot only after 200 MHz is qualified in this boot.
```powershell
& $s -Port $port -P12754 -Scenario Disp545Probe -AllowDisp545 -Disp545KHz 200000 -Execute
& $s @a -Audit53Module DISP400 -AllowDisp545
& $s @a -Audit53Module DISP200 -AllowDisp545
& $s @a -Audit53Module DISP400 -AllowDisp545
& $s -Port $port -P12754 -Scenario Disp545Probe -AllowDisp545 -Disp545KHz 200000 -Execute
& $s -P12754 -Scenario Audit53Compare -Audit53Reports @('ACTUAL-A0.json','ACTUAL-B.json','ACTUAL-A1.json') -Disp545Review 'ACTUAL-POST-A1.disp545-probe.json'
```

Use corresponding post-A1 probe file printed by host (confirm exact suffix). For 134 repeat with Disp545KHz 134000 and B DISP134. All A/B/A phases mask trigger; A is DISP400 zero SET. Failed rollback means recovery required; no subsequent experiment.

## Isolated MFC and ISPPRE
MFC keeps configured IRQ mode. Probe with screen OFF, connected; codec must be idle and post-restore six-frame CRC and real IRQ review must pass when IRQ configured. Camera requires real preview before pilot, then close and screen OFF; follow actual wake/preview/close/OFF prompts after rollback.
```powershell
& $s -Port $port -P12754 -Scenario Mfc545Probe -AllowMfc545 -Execute
& $s @a -Audit53Module STOCK60
& $s @a -Audit53Module MFCQCH -AllowMfc545
& $s @a -Audit53Module STOCK60
& $s -Port $port -P12754 -Scenario Mfc545Probe -AllowMfc545 -Execute
& $s -P12754 -Scenario Audit53Compare -Audit53Reports @('ACTUAL-A0.json','ACTUAL-B.json','ACTUAL-A1.json') -Qch545Review 'ACTUAL-POST-A1.mfc545-probe.json'
```

For camera, same sequence replacing Mfc545Probe with Cam545Probe, AllowMfc545 with AllowCam545, MFCQCH with ISPPREQCH, and the post-A1 review with actual cam545-probe.json. Do not combine QCH trials or force clocks if rejected.

## Other qualifications
Optional WIFI/TICKER: run FunctionalGate with GateModule WIFI or TICKER, AllowFunctionalGate and HeadlessNetwork, only with actual external peer proof. BT active owner HCI is not implemented; passive HCI witness is diagnostic only, do not enable BT composite on its basis. Panel trial is a separate connected test:
```powershell
& $s -Port $port -P12754 -Scenario Panel545 -AllowPanel545 -PanelCycles 3 -Execute
```

Follow per-cycle screen prompts, check visible frame and no tear. N on any problem. Panel temporal witness is not exact BO/DSC/TE or watts proof; no panel power saving qualification. INT/MIF read-only: Guard53 records ECT/MINLOCK and conservative bounds; live_verified=0/write_allowed=0, no SET. If ECT missing, do not bypass capture checks.

Send full logs and JSON (including failures, boot nonce, checkpoints, raw thermal/FG, guard, pre/post evidence and compare outputs); no selective pass-only reporting. No native CI failure or unqualified module should be treated as a reason to flash repeatedly. Review actual results before selecting further combined tests.
