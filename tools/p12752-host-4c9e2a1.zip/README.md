# P12.7.5.2 — test plan for one BOOT/SYSTEM build

Kernel: a77999584e54b31178ef9a86c7cabe9f99d628b5.
Host hotfix commit 4c9e2a1027211c047dac3dcb1661055ec4e5a92c changes only host scripts/tests; firmware a779995 remains compatible.
Use tools/p12752-host-4c9e2a1.zip. Replace all four scripts; do not mix versions.
Includes previous zero-only cleanup and closed-port handling fixes. P12752 offline capture no longer requires the Windows COM name to disappear. Adds frozen cutoff recovery without a new OFF measurement. No rebuild/flash required.
The first A0 raw log (121010) completed 60.208s, 31/31 thermal rows and P125/P127 mode zero; host aborted before exporting final WFI/FG reports.
The local tests are source/host mocks; actual native XNU/iOS SDK build,
flash, device stability, power and thermal improvement are unverified.

## Build once

Workflow s9-installer, branch fix/s9-p124-thermal-installer (new dispatch).
kernel_ref=s9/p12-4-guarded-thermal; packaging_ref=main; partition=SYSTEM.
metal=true, fps=true, time_limit=0, tweaks=true, userdata_blocks=starlte=13917184.

```text
hi=2 panel=1 p122=1 p12_gpu_boot_auto=1 mali_gov=1 mali_gov_frame=450 mali_probe=1 p3power=1 max77705_fg_s=10 p1273=1 p1274=1 p1275=1 p12751=1 p12752=1
```

Do not add fb_psr, bus_max, bus_mask, OPP overrides, p1272_probe=1,
metal_layout=1, CPU_OFF/CPU_SUSPEND or panel DCS experiments. P52 starts
with no idle intervention. Keep OptEarly (latch 3 or 7) and actual
libvulkan_panfrost_opt.dylib. Use paired BOOT/SYSTEM, retain userdata.
Confirm installer P12752 staged XNU header verified. Save artifact
p12751-panvk-macho to confirm optimized driver provenance.

## First run: idle baseline only (A0)

Extract the ZIP to one folder; run PowerShell there. Replace COM125 with
the actual port; close PuTTY. Fresh cool boot, screen OFF, leave USB
connected, do not swipe. Begin before the late poster burst. Do not run
P1274 burst capture or other policy trials simultaneously.

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -Scenario Idle52 -P12752Idle -EnergySeconds 60 -Port COM125 -Execute
```

Send the entire newly generated P125 log/report set (including .idle.csv,
.idle-info.txt, .idle-summary.json, .wfi.csv, .fg.csv, .counts.csv and raw
serial log). Early cutoff BIG67/LITTLE66/GPU68/BAT45, sustained combined
load >=200%, stale or wake aborts the phase. A cutoff is valid diagnostic
evidence but not a completed comparison. Do not repeat while hot.

## Next after reviewing A0: independent idle tests, no new flash

A0 uses P127_BASE (policy=1), which implies the existing P126 low four driver bits (driver=15); it is a matched policy baseline, not an entirely stock baseline. In firmware a779995 this inherited mask also prevents the new 13-domain P12752 GET path (`!r.driver`). BusTrace still reads the older eight cached P1273 domains with timestamp/errno/valid flags; do not infer a zero clock from invalid or missing readbacks. Full 13-domain collection requires a future kernel fix, not this host hotfix.

Use a fresh cool boot or matched quiet baseline for each command; never
stack policy leases. Host A/B/A is one module, not a suite. If evidence
is incomplete, a policy is refused, or wake/foreground fails, stop.
PSR uses governor threshold 100ms, not a legacy fb_psr timer. Frame
counter is not measured DSI/DRAM traffic. Verify wake and normal screen
updates manually after restoration before progressing.

```powershell
# All 13 ACPM GETs, separate diagnostic (not a pure power baseline)
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -Scenario BusTrace -P12752Idle -Port COM125 -Execute
# PSR A/B/A
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -Scenario EnergyTrials -P12752Idle -EnergyModules PSR -EnergySeconds 30 -Port COM125 -Execute
# First LITTLE floor A/B/A
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -Scenario EnergyTrials -P12752Idle -EnergyModules LITTLE949 -EnergySeconds 30 -Port COM125 -Execute
# One polling module only, after review
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -Scenario EnergyTrials -P12752Idle -EnergyModules BT -EnergySeconds 30 -Port COM125 -Execute
```

Other P127 modules USB, ABOX, WIFI, TICKER. P126: -Scenario DriverTrials
-DriverModules HAPTIC/WIFI/GNSS/TOUCH/LEEWAY/SHUB (choose one) -DriverSeconds 30.
LITTLE832 requires reviewed applied LITTLE949 A/B/A report:
-Scenario EnergyTrials -P12752Idle -EnergyModules LITTLE832
-AllowLowerFloor -P12752PriorReport <report.txt>. Then 715, then 598,
each with the immediately prior applied report and actual wake/UFS
review. A refusal is evidence; do not bypass input, UFS or thermal gates.

## Battery-only quiet window (after connected A0 review)

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p125-timer-serial.ps1 -Scenario Idle52Offline -P12752Idle -EnergySeconds 60 -AllowOfflineTrial -Port COM125 -Execute
```

Unplug/reconnect only at host prompts; do not wake screen, keep the
same boot. After unplug, COM may remain listed indefinitely while Read() reports
closed. The host closes the old handle immediately; COM enumeration is
advisory only for P12752. It holds the full 60s without opens, reads or
writes, then prompts RECONNECT USB NOW. It retries the exact requested
COM and read-only live fence with a bounded retry window. P125 phase/anchor
checks must pass before further policy writes. Kernel link-down/up and
actual duration (minimum 55s for the nominal 60s non-fixed window),
thermal coverage and external=0 fuel-gauge samples still determine validity;
a stale COM name or successful Open is not evidence of a physical link. If Windows assigns a different
COM on replug, use -ReconnectPort COMxxx on a fresh run with the known
port; never guess another serial device. If the previous run aborted,
use a fresh cooled boot before rearming (old leases may still be active).
Kernel stops autonomously for thermal/load/lease conditions.
If uncomfortable heat or malfunction, stop; do not continue a hot run.
Send partial logs too. Power.json uses signed FG samples, external=0,
negative current, contiguous sequence and >=80% temporal coverage.
A verified=false or missing file is no battery-power conclusion.
Connected net battery power is not device consumption.

## Later: workload + scheduler (fresh cool boot, after idle review)

First capture a matched LOG2 baseline or, when reviewed and eligible,
REC2. Explicit opt-in, arm before 225s. Existing 720s cap and hard stops
unchanged. Sampler observes natural busy workload between uptime 290–390s.
All eight remain online; recommended cores are not CPU hotplug.
OCP/UFS/input/topology refusals are deliberate. Never disable OCP.

```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -P12752 -Profile LOG2 -Experiment EarlyLoad -BootVariant OptEarly -AllowIntervention -Port COM125 -RunDir .\logs\P12752-LOG2-A0 -Execute
# Later, REC2 on a separate cool boot only:
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -P12752 -Profile R2 -Experiment EarlyLoad -BootVariant OptEarly -AllowIntervention -Port COM125 -RunDir .\logs\P12752-REC2-B -Execute
```

Dump and Analyze the actual run directory, same boot for Dump, when cool:
```powershell
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Action Dump -Port COM125 -RunDir .\logs\P12752-LOG2-A0 -MaxPages 192 -Execute
powershell -ExecutionPolicy Bypass -File .\s9-p1274-serial.ps1 -Action Analyze -RunDir .\logs\P12752-LOG2-A0 -Execute
```

Send whole directory even if dump_complete=false. Key P52 outputs:
p12752-samples.csv (PC/LR, not full stacks), sampler status, layout,
memory, lifecycle text, eligibility JSON plus existing stages and trace.
Only after a qualified REC2 including WakeCheck/operator review may
REC1 be attempted with -PriorReport <REC2-summary.json>; same for REC0
after qualified REC1. Never force repeated hot trials.

Deferred: bus writes INT/DISP, MIF, deep CPU suspend/off, DCS, full stack
unwinding, true texture layout/no-copy, alignment fast path and combined
policies. See kernel docs/s9-p12752-implementation-status.md.
